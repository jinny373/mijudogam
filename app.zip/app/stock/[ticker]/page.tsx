"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useParams, useRouter } from "next/navigation"
import { ArrowLeft, Share2, ThumbsUp, ThumbsDown, TrendingUp, Landmark, Rocket, Gem, ChevronRight, Heart, Search, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"
import { isInWatchlist, toggleWatchlist, logWatchlistEvent } from "@/lib/watchlist"
import { HeaderSearchModal } from "@/components/header-search-modal"

// 최근 본 종목 저장 (localStorage)
const RECENT_STOCKS_KEY = "mijudogam_recent_stocks"
const MAX_RECENT_STOCKS = 5

const saveRecentStock = (ticker: string, name: string) => {
  if (typeof window === "undefined") return
  try {
    const stored = localStorage.getItem(RECENT_STOCKS_KEY)
    const recent = stored ? JSON.parse(stored) : []
    const filtered = recent.filter((s: any) => s.ticker !== ticker)
    const updated = [{ ticker, name, viewedAt: Date.now() }, ...filtered].slice(0, MAX_RECENT_STOCKS)
    localStorage.setItem(RECENT_STOCKS_KEY, JSON.stringify(updated))
  } catch {
    // localStorage 에러 무시
  }
}

const iconMap: Record<string, any> = {
  earning: TrendingUp,
  debt: Landmark,
  growth: Rocket,
  valuation: Gem,
}

const statusColors = {
  green: { bg: "bg-[#22C55E]", text: "text-[#22C55E]", light: "bg-[#22C55E]/10" },
  yellow: { bg: "bg-[#EAB308]", text: "text-[#EAB308]", light: "bg-[#EAB308]/10" },
  red: { bg: "bg-[#EF4444]", text: "text-[#EF4444]", light: "bg-[#EF4444]/10" },
}

// ===== v9.20: 유사 종목 추천용 매핑 =====
const suggestionsMap: Record<string, { ticker: string; name: string }[]> = {
  // 검색 실패가 많았던 종목들
  "앱러빈": [{ ticker: "APP", name: "앱러빈" }],
  "알리바바": [{ ticker: "BABA", name: "알리바바" }],
  "샌디스크": [{ ticker: "SNDK", name: "샌디스크" }],
  "비트마인": [{ ticker: "BMNR", name: "비트마인이머션테크놀로지스" }],
  "비트": [{ ticker: "BMNR", name: "비트마인이머션테크놀로지스" }],
  "나비타스": [{ ticker: "NVTS", name: "나비타스세미컨덕터" }],
  "나비": [{ ticker: "NVTS", name: "나비타스세미컨덕터" }],
  "네비우스": [{ ticker: "NBIS", name: "네비우스그룹" }],
  "레드캣": [{ ticker: "RCAT", name: "레드캣홀딩스" }],
  "업스타트": [{ ticker: "UPST", name: "업스타트홀딩스" }],
  "셰니어": [{ ticker: "LNG", name: "셰니어에너지" }],
  "쉐니어": [{ ticker: "LNG", name: "셰니어에너지" }],
  "코크리스털": [{ ticker: "COCP", name: "코크리스털파마" }],
  "코크": [{ ticker: "COCP", name: "코크리스털파마" }],
  "보이저": [{ ticker: "VOYG", name: "보이저테크놀로지스" }],
  "써클": [{ ticker: "CRCL", name: "써클인터넷그룹" }],
  "뉴스케일": [{ ticker: "SMR", name: "뉴스케일파워" }],
  "팔란티어": [{ ticker: "PLTR", name: "팔란티어" }],
  "팔란이오": [{ ticker: "PLTR", name: "팔란티어" }],  // 오타 대응
  "팔랑티어": [{ ticker: "PLTR", name: "팔란티어" }],  // 오타 대응
  "팔란": [{ ticker: "PLTR", name: "팔란티어" }],  // 부분 검색
  "로켓": [{ ticker: "RKLB", name: "로켓랩" }],
  "로켓램": [{ ticker: "RKLB", name: "로켓랩" }],  // 오타 대응
  "로켓렙": [{ ticker: "RKLB", name: "로켓랩" }],  // 오타 대응
  "로켓랩": [{ ticker: "RKLB", name: "로켓랩" }],
  "리게티": [{ ticker: "RGTI", name: "리게티컴퓨팅" }],
  "리겟티": [{ ticker: "RGTI", name: "리게티컴퓨팅" }],
  "리게디": [{ ticker: "RGTI", name: "리게티컴퓨팅" }],  // 오타 대응
  "리게이티": [{ ticker: "RGTI", name: "리게티컴퓨팅" }],  // 오타 대응
  "캐터필": [{ ticker: "CAT", name: "캐터필러" }],
  "캐터필라": [{ ticker: "CAT", name: "캐터필러" }],  // 오타 대응
  "캐터필러": [{ ticker: "CAT", name: "캐터필러" }],
  "노던": [{ ticker: "NOG", name: "노던오일앤가스" }, { ticker: "NTRS", name: "노던트러스트" }],
  // v9.21: 추가 인기 종목 오타/별칭
  "엔비디아": [{ ticker: "NVDA", name: "엔비디아" }],
  "앤비디아": [{ ticker: "NVDA", name: "엔비디아" }],  // 오타 대응
  "엔비디야": [{ ticker: "NVDA", name: "엔비디아" }],  // 오타 대응
  "테슬라": [{ ticker: "TSLA", name: "테슬라" }],
  "테슬러": [{ ticker: "TSLA", name: "테슬라" }],  // 오타 대응
  "아마존": [{ ticker: "AMZN", name: "아마존" }],
  "아마존닷컴": [{ ticker: "AMZN", name: "아마존" }],
  "애플": [{ ticker: "AAPL", name: "애플" }],
  "에플": [{ ticker: "AAPL", name: "애플" }],  // 오타 대응
  "마이크로소프트": [{ ticker: "MSFT", name: "마이크로소프트" }],
  "마소": [{ ticker: "MSFT", name: "마이크로소프트" }],  // 줄임말
  "구글": [{ ticker: "GOOGL", name: "알파벳(구글)" }],
  "알파벳": [{ ticker: "GOOGL", name: "알파벳(구글)" }],
  "메타": [{ ticker: "META", name: "메타(페이스북)" }],
  "페이스북": [{ ticker: "META", name: "메타(페이스북)" }],
  "인텔": [{ ticker: "INTC", name: "인텔" }],
  "AMD": [{ ticker: "AMD", name: "AMD" }],
  "에이엠디": [{ ticker: "AMD", name: "AMD" }],
  "아이온큐": [{ ticker: "IONQ", name: "아이온큐" }],
  "아이온Q": [{ ticker: "IONQ", name: "아이온큐" }],
  "퀀텀": [{ ticker: "QBTS", name: "디웨이브퀀텀" }, { ticker: "IONQ", name: "아이온큐" }],
  "디웨이브": [{ ticker: "QBTS", name: "디웨이브퀀텀" }],
  "코인베이스": [{ ticker: "COIN", name: "코인베이스" }],
  "코인": [{ ticker: "COIN", name: "코인베이스" }],
  "마이크로스트레티지": [{ ticker: "MSTR", name: "마이크로스트래티지" }],
  "마스트": [{ ticker: "MSTR", name: "마이크로스트래티지" }],  // 줄임말
  // v9.22: 추가 종목
  "온다스": [{ ticker: "ONDS", name: "온다스홀딩스" }],
  "온다스홀딩스": [{ ticker: "ONDS", name: "온다스홀딩스" }],
  "팔란티어": [{ ticker: "PLTR", name: "팔란티어" }],
  "팔란": [{ ticker: "PLTR", name: "팔란티어" }],  // 줄임말
  "브로드컴": [{ ticker: "AVGO", name: "브로드컴" }],
  "TSMC": [{ ticker: "TSM", name: "TSMC(대만반도체)" }],
  "대만반도체": [{ ticker: "TSM", name: "TSMC(대만반도체)" }],
  "오라클": [{ ticker: "ORCL", name: "오라클" }],
  "세일즈포스": [{ ticker: "CRM", name: "세일즈포스" }],
  "넷플릭스": [{ ticker: "NFLX", name: "넷플릭스" }],
  "디즈니": [{ ticker: "DIS", name: "디즈니" }],
  "월마트": [{ ticker: "WMT", name: "월마트" }],
  "코스트코": [{ ticker: "COST", name: "코스트코" }],
  "비자": [{ ticker: "V", name: "비자" }],
  "마스터카드": [{ ticker: "MA", name: "마스터카드" }],
  "제이피모건": [{ ticker: "JPM", name: "JP모건" }],
  "JP모건": [{ ticker: "JPM", name: "JP모건" }],
  "골드만삭스": [{ ticker: "GS", name: "골드만삭스" }],
  "나이키": [{ ticker: "NKE", name: "나이키" }],
  "스타벅스": [{ ticker: "SBUX", name: "스타벅스" }],
  "맥도날드": [{ ticker: "MCD", name: "맥도날드" }],
  "코카콜라": [{ ticker: "KO", name: "코카콜라" }],
  "펩시": [{ ticker: "PEP", name: "펩시코" }],
  "존슨앤존슨": [{ ticker: "JNJ", name: "존슨앤존슨" }],
  "화이자": [{ ticker: "PFE", name: "화이자" }],
  "일라이릴리": [{ ticker: "LLY", name: "일라이릴리" }],
  "엑슨모빌": [{ ticker: "XOM", name: "엑슨모빌" }],
  "쉐브론": [{ ticker: "CVX", name: "쉐브론" }],
}

// 유사 종목 찾기 (v9.22: 티커로도 검색 가능)
const findSuggestions = (query: string): { ticker: string; name: string }[] => {
  const decoded = decodeURIComponent(query)
  const decodedLower = decoded.toLowerCase()
  const decodedUpper = decoded.toUpperCase()
  
  // 1. 한글 키워드로 검색
  for (const [keyword, suggestions] of Object.entries(suggestionsMap)) {
    if (decodedLower.includes(keyword.toLowerCase()) || keyword.toLowerCase().includes(decodedLower)) {
      return suggestions
    }
  }
  
  // 2. 티커로 검색 (역방향) - APP → 앱러빈
  for (const [keyword, suggestions] of Object.entries(suggestionsMap)) {
    for (const suggestion of suggestions) {
      if (suggestion.ticker.toUpperCase() === decodedUpper) {
        return suggestions
      }
    }
  }
  
  return []
}

function LoadingSkeleton() {
  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-10 bg-background border-b px-4 py-3">
        <div className="flex items-center justify-between max-w-2xl mx-auto">
          <Skeleton className="h-10 w-10 rounded-full" />
          <Skeleton className="h-6 w-20" />
          <Skeleton className="h-10 w-10 rounded-full" />
        </div>
      </header>
      <main className="px-4 py-6 max-w-2xl mx-auto space-y-6">
        <div className="space-y-2">
          <Skeleton className="h-8 w-32" />
          <Skeleton className="h-5 w-40" />
          <Skeleton className="h-10 w-28" />
        </div>
        <Skeleton className="h-32 w-full rounded-2xl" />
        <div className="grid grid-cols-2 gap-4">
          <Skeleton className="h-40 rounded-xl" />
          <Skeleton className="h-40 rounded-xl" />
        </div>
        <div className="grid grid-cols-2 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <Skeleton key={i} className="h-44 rounded-xl" />
          ))}
        </div>
      </main>
    </div>
  )
}

// ===== v9.20: ErrorState 개선 =====
function ErrorState({ message, ticker, onRetry }: { message: string; ticker?: string; onRetry?: () => void }) {
  const router = useRouter()
  const [isRetrying, setIsRetrying] = useState(false)
  
  // URL 인코딩된 한글 디코딩
  const decodedTicker = ticker ? decodeURIComponent(ticker) : null
  const upperTicker = decodedTicker?.toUpperCase()
  
  // v9.20: 유사 종목 추천
  const allSuggestions = decodedTicker ? findSuggestions(decodedTicker) : []
  
  // v9.22: 추천 종목 중 현재 티커와 일치하는 것 찾기 (API 에러 케이스)
  const matchingSuggestion = allSuggestions.find(s => s.ticker.toUpperCase() === upperTicker)
  
  // 현재 티커와 다른 추천만 표시
  const suggestions = allSuggestions.filter(s => s.ticker.toUpperCase() !== upperTicker)
  
  const handleRetryWithTicker = async (tickerToRetry: string) => {
    setIsRetrying(true)
    // 강제 새로고침으로 재시도
    window.location.href = `/stock/${tickerToRetry}`
  }
  
  return (
    <div className="min-h-screen bg-background flex flex-col">
      <header className="sticky top-0 z-10 bg-background border-b px-4 py-3">
        <div className="flex items-center justify-between max-w-2xl mx-auto">
          <Button variant="ghost" size="icon" className="rounded-full" onClick={() => router.back()}>
            <ArrowLeft className="h-5 w-5" />
            <span className="sr-only">뒤로가기</span>
          </Button>
          <Link href="/" className="hover:opacity-80 transition-opacity">
            <span className="text-lg font-bold text-primary">미주도감</span>
          </Link>
          <div className="w-10" />
        </div>
      </header>
      <main className="flex-1 flex items-center justify-center px-4 py-8">
        <div className="text-center space-y-4 max-w-sm w-full">
          {/* v9.22: API 에러 (올바른 티커인데 데이터 못 가져옴) */}
          {matchingSuggestion ? (
            <>
              <div className="text-4xl">⏳</div>
              <p className="text-foreground text-lg font-medium">
                데이터를 불러오는 중 문제가 생겼어요
              </p>
              <p className="text-muted-foreground text-sm">
                Yahoo Finance 서버가 응답하지 않아요
              </p>
              <div className="space-y-2 pt-2">
                <Button 
                  onClick={() => handleRetryWithTicker(matchingSuggestion.ticker)}
                  disabled={isRetrying}
                  className="rounded-full px-6 w-full"
                >
                  {isRetrying ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin mr-2" />
                      다시 시도 중...
                    </>
                  ) : (
                    `${matchingSuggestion.name} (${matchingSuggestion.ticker}) 다시 시도`
                  )}
                </Button>
                <Link href="/" className="block">
                  <Button variant="outline" className="rounded-full px-6 w-full">
                    다른 종목 검색
                  </Button>
                </Link>
              </div>
            </>
          ) : (
            <>
              <div className="text-4xl">😅</div>
              <p className="text-foreground text-lg font-medium">
                {decodedTicker ? `"${decodedTicker}" 종목을 찾을 수 없어요` : "종목을 찾을 수 없어요"}
              </p>
              
              {/* 유사 종목 추천 */}
              {suggestions.length > 0 && (
                <div className="bg-primary/5 rounded-xl p-4 text-left">
                  <p className="text-sm font-medium text-foreground flex items-center gap-2 mb-3">
                    <Search className="h-4 w-4" />
                    이 종목을 찾으셨나요?
                  </p>
                  <div className="space-y-2">
                    {suggestions.map((stock) => (
                      <button
                        key={stock.ticker}
                        onClick={() => router.push(`/stock/${stock.ticker}`)}
                        className="w-full px-4 py-3 bg-background rounded-lg border hover:border-primary hover:bg-primary/5 transition-colors text-left flex items-center justify-between"
                      >
                        <div>
                          <span className="font-semibold text-primary">{stock.ticker}</span>
                          <span className="text-muted-foreground ml-2 text-sm">{stock.name}</span>
                        </div>
                        <ChevronRight className="h-4 w-4 text-muted-foreground" />
                      </button>
                    ))}
                  </div>
                </div>
              )}
              
              <p className="text-muted-foreground text-sm">
                영문 티커(AAPL, TSLA) 또는 종목코드(005930)로 검색해보세요
              </p>
              <Link href="/">
                <Button className="rounded-full px-6">새로운 종목 검색</Button>
              </Link>
            </>
          )}
        </div>
      </main>
    </div>
  )
}

export default function StockDetailPage() {
  const params = useParams()
  const ticker = params.ticker as string

  const [stockData, setStockData] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [isWatchlisted, setIsWatchlisted] = useState(false)
  const [feedback, setFeedback] = useState<"up" | "down" | null>(null)
  const [isSearchOpen, setIsSearchOpen] = useState(false)

  // fetchData를 컴포넌트 스코프로 이동 (재시도 가능하게)
  const fetchData = async () => {
    try {
      setIsLoading(true)
      setError(null)

      // URL 디코딩 (브라우저가 특수문자를 인코딩할 수 있음)
      const decodedTicker = decodeURIComponent(ticker)
      
      // 한국 주식 감지:
      // 1) 숫자.KS 또는 숫자.KQ 패턴 (정상 경로)
      // 2) 6자리 순수 숫자 (URL에서 .KS가 잘린 경우 대비)
      const isKR = /^\d+\.(KS|KQ)$/i.test(decodedTicker) || /^\d{6}$/.test(decodedTicker)
      
      let apiUrl: string
      if (isKR) {
        // 한국 주식: stock-kr API 사용
        const stockCode = decodedTicker.split(".")[0] // "005930.KS" → "005930", "005930" → "005930"
        apiUrl = `/api/stock-kr/${stockCode}?v=${Date.now()}`
      } else {
        // 미국 주식: 기존 API
        apiUrl = `/api/stock/${decodedTicker}?v=${Date.now()}`
      }

      const response = await fetch(apiUrl)
      const data = await response.json()

      if (!response.ok) {
        setError(data.error || "데이터를 불러올 수 없어요")
        return
      }

      // 한국 주식인 경우 데이터 구조 통일
      if (data.isKorean && data.basicInfo) {
        // signalDetails → metrics 배열 변환 (핵심체크 카드용)
        const signalToStatus = (s: string) => s === "green" ? "green" : s === "red" ? "red" : "yellow"
        const krMetrics = []
        
        if (data.signalDetails?.earning) {
          krMetrics.push({
            id: "earning",
            title: "돈 버는 능력",
            emoji: "💰",
            status: signalToStatus(data.signalDetails.earning.status),
            statusText: data.signalDetails.earning.status === "green" ? "우수" : data.signalDetails.earning.status === "red" ? "주의" : "보통",
            summary: data.signalDetails.earning.label,
            mainValue: `${data.financials.roe?.toFixed(1) || 0}%`,
            mainLabel: "ROE",
            average: `${data.financials.dartYear || "2025"}년 기준`,
          })
        }
        if (data.signalDetails?.debt) {
          krMetrics.push({
            id: "debt",
            title: "빚 관리",
            emoji: "🏦",
            status: signalToStatus(data.signalDetails.debt.status),
            statusText: data.signalDetails.debt.status === "green" ? "우수" : data.signalDetails.debt.status === "red" ? "주의" : "보통",
            summary: data.signalDetails.debt.label,
            mainValue: `${(data.financials.debtRatio * 100)?.toFixed(1) || 0}%`,
            mainLabel: "부채비율",
            average: `${data.financials.dartYear || "2025"}년 기준`,
          })
        }
        if (data.signalDetails?.growth) {
          krMetrics.push({
            id: "growth",
            title: "성장 가능성",
            emoji: "🚀",
            status: signalToStatus(data.signalDetails.growth.status),
            statusText: data.signalDetails.growth.status === "green" ? "고성장" : data.signalDetails.growth.status === "red" ? "역성장" : "성장중",
            summary: data.signalDetails.growth.label,
            mainValue: `+${data.financials.revenueGrowth?.toFixed(1) || 0}%`,
            mainLabel: "매출 성장률",
            average: `${data.financials.dartYear || "2025"}년 기준`,
          })
        }
        if (data.signalDetails?.valuation) {
          krMetrics.push({
            id: "valuation",
            title: "현재 몸값",
            emoji: "💎",
            status: signalToStatus(data.signalDetails.valuation.status),
            statusText: data.signalDetails.valuation.status === "green" ? "낮은 편" : data.signalDetails.valuation.status === "red" ? "높은 편" : "적정",
            summary: data.signalDetails.valuation.label,
            mainValue: `${data.financials.per?.toFixed(1) || 0}배`,
            mainLabel: `PER (${data.financials.perType || "Forward"})`,
            average: "현재 주가 기준",
          })
        }

        // 한국 주식용 AI 한마디 생성
        const fin = data.financials
        const krSummaryParts = []
        
        const safeGrowth = Number(fin.revenueGrowth) || 0
        const safeRoe = Number(fin.roe) || 0
        const safeDebtRatio = Number(fin.debtRatio) || 0
        const safePer = Number(fin.per) || 0
        
        // 성장성
        if (safeGrowth > 50) {
          krSummaryParts.push(`매출이 폭발적으로 성장 중이에요 (+${safeGrowth.toFixed(1)}%).`)
        } else if (safeGrowth > 15) {
          krSummaryParts.push(`매출이 빠르게 성장 중이에요 (+${safeGrowth.toFixed(1)}%).`)
        } else if (safeGrowth > 0) {
          krSummaryParts.push(`매출이 꾸준히 성장 중이에요 (+${safeGrowth.toFixed(1)}%).`)
        } else if (safeGrowth < -10) {
          krSummaryParts.push(`매출이 감소하고 있어요 (${safeGrowth.toFixed(1)}%).`)
        } else {
          krSummaryParts.push("매출 성장이 정체 상태예요.")
        }
        
        // 수익성 + 재무
        if (safeRoe > 15 && safeDebtRatio < 0.5) {
          krSummaryParts.push("돈도 잘 벌고 빚도 적어서 재무 상태가 튼튼해요.")
        } else if (safeRoe > 15) {
          krSummaryParts.push("돈은 잘 버는 편이에요.")
        } else if (safeDebtRatio < 0.3) {
          krSummaryParts.push("자본 대비 빚 부담이 적어서 재무가 안정적이에요.")
        } else if (safeDebtRatio > 1) {
          krSummaryParts.push("빚이 많은 편이라 재무 건전성에 주의가 필요해요.")
        } else {
          krSummaryParts.push("재무 상태는 평균적인 수준이에요.")
        }
        
        // 밸류에이션
        if (safePer > 0 && safePer < 10) {
          krSummaryParts.push("PER이 매우 낮아서 저평가 매력이 있을 수 있어요.")
        } else if (safePer > 0 && safePer < 15) {
          krSummaryParts.push("PER이 낮은 편이라 가격 매력이 있어요.")
        } else if (safePer > 30) {
          krSummaryParts.push("PER이 높은 편이라 성장 기대가 반영된 가격이에요.")
        } else if (safePer > 0) {
          krSummaryParts.push("PER은 적정 수준이에요.")
        } else {
          krSummaryParts.push("현재 PER 데이터를 확인할 수 없어요.")
        }
        
        const krAiSummary = krSummaryParts.join(" ")

        const converted = {
          ...data,
          name: data.basicInfo.name,
          ticker: data.basicInfo.ticker,
          exchange: data.basicInfo.exchange,
          price: data.basicInfo.price,
          change: data.basicInfo.change,
          changePercent: data.basicInfo.changePercent,
          marketCap: data.basicInfo.marketCap,
          volume: data.basicInfo.volume,
          sector: data.basicInfo.sector,
          industry: data.basicInfo.industry,
          signals: data.signals,
          signalDetails: data.signalDetails,
          metrics: krMetrics,
          aiSummary: krAiSummary,
          // 한국 전용 필드
          isKorean: true,
          benchmarkName: data.benchmarkName || "KOSPI",
          stockCode: data.basicInfo.stockCode,
          // 재무 데이터
          roe: data.financials.roe,
          operatingMargin: data.financials.operatingMargin,
          profitMargin: data.financials.profitMargin,
          debtToEquity: data.financials.debtRatio,
          revenueGrowth: data.financials.revenueGrowth,
          per: data.financials.per,
          perType: data.financials.perType,
          pbr: data.financials.pbr,
          revenue: data.financials.revenue,
          revenueFormatted: data.financials.revenueFormatted,
          netIncome: data.financials.netIncome,
          netIncomeFormatted: data.financials.netIncomeFormatted,
          dataSource: data.financials.dataSource,
          dartYear: data.financials.dartYear,
          // 주가 성과
          performance: data.performance,
          priceInfo: data.priceInfo,
        }
        setStockData(converted)
      } else {
        setStockData(data)
      }

      setIsWatchlisted(isInWatchlist(ticker))
      
      // 최근 본 종목에 저장
      const stockName = isKR ? data.basicInfo?.name : data.name
      saveRecentStock(ticker.toUpperCase(), stockName || ticker)
      
      // 페이지뷰 로깅
      logWatchlistEvent("stock_view", { ticker: ticker.toUpperCase(), name: stockName || ticker })
    } catch (err) {
      console.error("Error:", err)
      setError("데이터를 불러오는 중 오류가 발생했어요")
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    if (ticker) {
      fetchData()
    }
  }, [ticker])

  const handleToggleWatchlist = () => {
    if (!stockData) return
    
    // toggleWatchlist(ticker, name) - 두 개의 문자열 인자
    const newState = toggleWatchlist(stockData.ticker, stockData.name)
    setIsWatchlisted(newState)
    
    logWatchlistEvent(newState ? "watchlist_add" : "watchlist_remove", { 
      ticker: stockData.ticker,
      name: stockData.name 
    })
  }

  const handleShare = async () => {
    if (!stockData) return
    
    const shareData = {
      title: `${stockData.name} (${stockData.ticker}) - 미주도감`,
      text: stockData.aiSummary,
      url: window.location.href,
    }

    try {
      if (navigator.share) {
        await navigator.share(shareData)
        logWatchlistEvent("share_native", { ticker: stockData.ticker })
      } else {
        await navigator.clipboard.writeText(window.location.href)
        alert("링크가 복사되었어요!")
        logWatchlistEvent("share_clipboard", { ticker: stockData.ticker })
      }
    } catch (err) {
      console.log("Share failed:", err)
    }
  }

  if (isLoading) return <LoadingSkeleton />
  if (error) return <ErrorState message={error} ticker={ticker} onRetry={fetchData} />
  if (!stockData) return <ErrorState message="데이터를 찾을 수 없어요" ticker={ticker} onRetry={fetchData} />

  const isPositive = stockData.change >= 0

  return (
    <div className="min-h-screen bg-background">
      {/* 검색 모달 */}
      <HeaderSearchModal isOpen={isSearchOpen} onClose={() => setIsSearchOpen(false)} />
      
      {/* Header with Search */}
      <header className="sticky top-0 z-10 bg-background/95 backdrop-blur border-b px-4 py-3">
        <div className="flex items-center gap-2 max-w-2xl mx-auto">
          <Button variant="ghost" size="icon" className="rounded-full flex-shrink-0" onClick={() => router.back()}>
            <ArrowLeft className="h-5 w-5" />
            <span className="sr-only">뒤로가기</span>
          </Button>
          {/* 검색바 - 클릭 시 모달 열기 */}
          <div 
            className="flex-1 min-w-0 flex items-center gap-2 px-3 py-2 rounded-full bg-muted/50 border cursor-pointer hover:bg-muted transition-colors"
            onClick={() => setIsSearchOpen(true)}
          >
            <Search className="h-4 w-4 text-muted-foreground flex-shrink-0" />
            <span className="text-sm text-muted-foreground truncate">종목 검색</span>
          </div>
          <Button variant="ghost" size="icon" className="rounded-full flex-shrink-0" onClick={handleShare}>
            <Share2 className="h-5 w-5" />
            <span className="sr-only">공유하기</span>
          </Button>
        </div>
      </header>

      <main className="px-4 py-6 max-w-2xl mx-auto space-y-6">
        {/* Stock Basic Info */}
        <section>
          <div className="flex items-start justify-between">
            <div>
              <h1 className="text-2xl font-bold text-foreground">{stockData.name}</h1>
              <p className="text-muted-foreground">
                {stockData.ticker} · {stockData.exchange}
              </p>
            </div>
            <button
              onClick={handleToggleWatchlist}
              className={`p-2 rounded-full transition-colors ${
                isWatchlisted 
                  ? "text-red-500 bg-red-50 hover:bg-red-100" 
                  : "text-muted-foreground bg-muted hover:bg-muted/80"
              }`}
              title={isWatchlisted ? "관심목록에서 제거" : "관심목록에 추가"}
            >
              <Heart className={`h-6 w-6 ${isWatchlisted ? "fill-current" : ""}`} />
            </button>
          </div>
          <div className="mt-2 flex items-baseline gap-3">
            {stockData.isKorean ? (
              <>
                <span className="text-3xl font-bold">{Number(stockData.price).toLocaleString()}원</span>
                <span className={`text-lg font-semibold ${isPositive ? "text-[#22C55E]" : "text-[#EF4444]"}`}>
                  {isPositive ? "+" : ""}{Number(stockData.change).toLocaleString()}원 ({isPositive ? "+" : ""}{stockData.changePercent?.toFixed(2)}%)
                </span>
              </>
            ) : (
              <>
                <span className="text-3xl font-bold">${stockData.price?.toFixed(2)}</span>
                <span className={`text-lg font-semibold ${isPositive ? "text-[#22C55E]" : "text-[#EF4444]"}`}>
                  {isPositive ? "+" : ""}${stockData.change?.toFixed(2)} ({isPositive ? "+" : ""}{stockData.changePercent?.toFixed(2)}%)
                </span>
              </>
            )}
          </div>
        </section>

        {/* AI Summary Card - 한국/미국 모두 */}
        {stockData.aiSummary && (
          <Card className="bg-primary p-5 rounded-2xl border-0 shadow-lg">
            <p className="text-primary-foreground/80 text-sm font-medium mb-1">📌 이 종목을 한마디로?</p>
            <p className="text-primary-foreground text-lg font-semibold leading-relaxed">
              {stockData.aiSummary}
            </p>
          </Card>
        )}

        {/* Pros and Cons - 미국 주식만 */}
        {!stockData.isKorean && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Pros */}
          <Card className="p-4 rounded-xl border shadow-sm">
            <h3 className="text-[#22C55E] font-semibold mb-3 flex items-center gap-2">
              <span className="text-base">✅ 좋은 점</span>
            </h3>
            <ul className="space-y-2">
              {stockData.pros?.map((pro: string, i: number) => (
                <li key={i} className="flex items-start gap-2 text-sm text-foreground">
                  <span className="text-[#22C55E] mt-0.5">•</span>
                  <span>{pro}</span>
                </li>
              ))}
            </ul>
          </Card>

          {/* Cons */}
          <Card className="p-4 rounded-xl border shadow-sm">
            <h3 className="text-[#EAB308] font-semibold mb-3 flex items-center gap-2">
              <span className="text-base">⚠️ 알고 갈 점</span>
            </h3>
            <ul className="space-y-2">
              {stockData.cons?.map((con: string, i: number) => (
                <li key={i} className="flex items-start gap-2 text-sm text-foreground">
                  <span className="text-[#EAB308] mt-0.5">•</span>
                  <span>{con}</span>
                </li>
              ))}
            </ul>
          </Card>
        </div>
        )}

        {/* Key Metrics */}
        <section>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold text-foreground">📊 핵심 체크</h2>
            <div className="flex items-center gap-3 text-xs text-muted-foreground">
              <span className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-[#22C55E]"></span>
                좋음
              </span>
              <span className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-[#EAB308]"></span>
                보통
              </span>
              <span className="flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-[#EF4444]"></span>
                주의
              </span>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            {stockData.metrics?.map((metric: any, i: number) => {
              const colors = statusColors[metric.status as keyof typeof statusColors] || statusColors.yellow
              const Icon = iconMap[metric.id] || TrendingUp
              
              return (
                <Link 
                  key={i} 
                  href={`/stock/${stockData.ticker}/metric/${metric.id}`}
                  onClick={() => logWatchlistEvent("metric_card_click", { 
                    ticker: stockData.ticker, 
                    metric_id: metric.id,
                    metric_title: metric.title 
                  })}
                >
                  <Card className="p-4 rounded-xl border shadow-sm hover:shadow-md transition-shadow cursor-pointer h-full flex flex-col">
                    <div className="flex items-center justify-between mb-2">
                      <div className={`p-2 rounded-lg ${colors.light}`}>
                        <Icon className={`h-5 w-5 ${colors.text}`} />
                      </div>
                      <div className="flex items-center gap-1">
                        <div className={`w-3 h-3 rounded-full ${colors.bg}`} />
                        <ChevronRight className="h-4 w-4 text-muted-foreground" />
                      </div>
                    </div>
                    <h4 className="font-semibold text-foreground text-sm">{metric.title}</h4>
                    <p className="text-muted-foreground text-base mt-0.5 mb-3 leading-snug flex-1">{metric.summary}</p>
                    <div className="mt-auto">
                      <div>
                        <span className="text-2xl font-bold text-foreground">{metric.mainValue}</span>
                        <span className="text-xs text-muted-foreground ml-1">{metric.mainLabel}</span>
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">{metric.average}</p>
                    </div>
                  </Card>
                </Link>
              )
            })}
          </div>
        </section>

        {/* v9.41: 관련 종목 추천 - 테이블 스타일 UI */}
        {stockData.relatedStocks && stockData.relatedStocks.length > 0 && (
          <section className="pt-2">
            {/* Header */}
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-4">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-purple-100 flex items-center justify-center">
                  <span className="text-lg">🔗</span>
                </div>
                <h2 className="text-lg font-bold text-foreground">함께 보면 좋은 종목</h2>
              </div>
              {/* 범례 */}
              <div className="flex items-center gap-3 text-xs bg-muted/50 rounded-full px-3 py-1.5 w-fit">
                <div className="flex items-center gap-1.5">
                  <div className="w-2 h-2 rounded-full bg-emerald-500" />
                  <span className="text-muted-foreground">좋음</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <div className="w-2 h-2 rounded-full bg-amber-400" />
                  <span className="text-muted-foreground">보통</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <div className="w-2 h-2 rounded-full bg-rose-500" />
                  <span className="text-muted-foreground">주의</span>
                </div>
              </div>
            </div>

            {/* Table */}
            <Card className="rounded-2xl border shadow-sm overflow-hidden p-0">
              {/* Table Header */}
              <div className="flex items-center px-4 h-[44px] bg-muted/40 border-b border-border/60">
                <div className="flex-1 text-sm font-bold text-foreground">종목</div>
                <div className="flex items-center gap-0">
                  <div className="w-[40px] sm:w-[52px] text-sm font-bold text-foreground text-center">수익</div>
                  <div className="w-[40px] sm:w-[52px] text-sm font-bold text-foreground text-center">빚</div>
                  <div className="w-[40px] sm:w-[52px] text-sm font-bold text-foreground text-center">성장</div>
                  <div className="w-[40px] sm:w-[52px] text-sm font-bold text-foreground text-center">몸값</div>
                </div>
                <div className="w-[28px] sm:w-[36px]" />
              </div>

              {/* Table Body - 첫 번째 행은 border-t 없음 */}
              {stockData.relatedStocks.map((stock: { 
                ticker: string; 
                name: string; 
                nameKo: string; 
                reason: string;
                signals?: {
                  earning: "good" | "normal" | "bad";
                  debt: "good" | "normal" | "bad";
                  growth: "good" | "normal" | "bad";
                  valuation: "good" | "normal" | "bad";
                } | null;
              }, index: number) => {
                // 신호등 색상 매핑
                const getRatingClass = (signal?: "good" | "normal" | "bad") => {
                  if (!signal) return "bg-gray-300";
                  if (signal === "good") return "bg-emerald-500 shadow-emerald-500/30";
                  if (signal === "normal") return "bg-amber-400 shadow-amber-400/30";
                  return "bg-rose-500 shadow-rose-500/30";
                };
                
                return (
                  <div
                    key={stock.ticker}
                    className={`flex items-center px-4 h-[72px] hover:bg-primary/[0.03] cursor-pointer transition-all duration-200 group ${index > 0 ? 'border-t border-border/60' : ''}`}
                    onClick={() => {
                      logWatchlistEvent("related_stock_click", { 
                        from: stockData.ticker, 
                        to: stock.ticker 
                      })
                      window.location.href = `/stock/${stock.ticker}`
                    }}
                  >
                      {/* Stock Info */}
                      <div className="flex-1 min-w-0 pr-2">
                        <span className="font-bold text-foreground truncate block text-base sm:text-lg leading-tight">{stock.nameKo || stock.name}</span>
                        <div className="flex items-center gap-1.5 mt-0.5">
                          <span className="text-xs font-semibold text-purple-600">{stock.ticker}</span>
                          <span className="text-[11px] text-muted-foreground truncate">{stock.reason}</span>
                        </div>
                      </div>

                      {/* Metrics - 고정 너비 */}
                      <div className="flex items-center gap-0">
                        {stock.signals ? (
                          <>
                            <div className="w-[40px] sm:w-[52px] flex justify-center">
                              <div className={`w-2.5 h-2.5 rounded-full shadow-md ${getRatingClass(stock.signals.earning)}`} />
                            </div>
                            <div className="w-[40px] sm:w-[52px] flex justify-center">
                              <div className={`w-2.5 h-2.5 rounded-full shadow-md ${getRatingClass(stock.signals.debt)}`} />
                            </div>
                            <div className="w-[40px] sm:w-[52px] flex justify-center">
                              <div className={`w-2.5 h-2.5 rounded-full shadow-md ${getRatingClass(stock.signals.growth)}`} />
                            </div>
                            <div className="w-[40px] sm:w-[52px] flex justify-center">
                              <div className={`w-2.5 h-2.5 rounded-full shadow-md ${getRatingClass(stock.signals.valuation)}`} />
                            </div>
                          </>
                        ) : (
                          <>
                            <div className="w-[40px] sm:w-[52px] flex justify-center"><div className="w-2.5 h-2.5 rounded-full bg-gray-300" /></div>
                            <div className="w-[40px] sm:w-[52px] flex justify-center"><div className="w-2.5 h-2.5 rounded-full bg-gray-300" /></div>
                            <div className="w-[40px] sm:w-[52px] flex justify-center"><div className="w-2.5 h-2.5 rounded-full bg-gray-300" /></div>
                            <div className="w-[40px] sm:w-[52px] flex justify-center"><div className="w-2.5 h-2.5 rounded-full bg-gray-300" /></div>
                          </>
                        )}
                      </div>

                      {/* Arrow */}
                      <div className="w-[28px] sm:w-[36px] flex justify-center">
                        <div className="w-6 h-6 rounded-full flex items-center justify-center group-hover:bg-purple-100 transition-colors">
                          <ChevronRight className="w-4 h-4 text-muted-foreground group-hover:text-purple-600 group-hover:translate-x-0.5 transition-all" />
                        </div>
                      </div>
                    </div>
                  );
                })}
            </Card>
          </section>
        )}

        {/* Feedback CTA */}
        <section className="pt-4 pb-8">
          <Card className="p-5 rounded-xl border shadow-sm text-center">
            <p className="text-foreground font-medium mb-4">이 분석이 도움이 됐나요?</p>
            <div className="flex justify-center gap-4">
              <Button
                variant={feedback === "up" ? "default" : "outline"}
                size="lg"
                className={`rounded-full px-6 ${feedback === "up" ? "bg-primary" : ""}`}
                onClick={() => {
                  setFeedback("up")
                  logWatchlistEvent("feedback_up", { ticker: stockData.ticker })
                }}
              >
                <ThumbsUp className="h-5 w-5 mr-2" />
                좋아요
              </Button>
              <Button
                variant={feedback === "down" ? "default" : "outline"}
                size="lg"
                className={`rounded-full px-6 ${feedback === "down" ? "bg-muted-foreground" : ""}`}
                onClick={() => {
                  setFeedback("down")
                  logWatchlistEvent("feedback_down", { ticker: stockData.ticker })
                }}
              >
                <ThumbsDown className="h-5 w-5 mr-2" />
                아쉬워요
              </Button>
            </div>
            {feedback && (
              <p className="text-sm text-muted-foreground mt-4">
                피드백 감사합니다!
              </p>
            )}
          </Card>
          
          {/* Data Source Notice */}
          {stockData.isKorean ? (
            <div className="text-center mt-4 space-y-2">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-800">
                <span className="text-sm">🇰🇷</span>
                <span className="text-xs font-medium text-blue-700 dark:text-blue-300">한국 주식</span>
              </div>
              <p className="text-xs text-muted-foreground">
                재무 데이터: {stockData.dataSource || "DART"} ({stockData.dartYear}년) · 주가: Yahoo Finance · 벤치마크: {stockData.benchmarkName || "KOSPI"}
              </p>
              <p className="text-xs text-muted-foreground">
                ⚠️ 본 자료는 투자 참고용이며, 투자 판단의 책임은 투자자에게 있습니다.
              </p>
            </div>
          ) : stockData.dataSource && typeof stockData.dataSource === 'object' ? (
            <div className="text-center mt-4 space-y-1">
              <p className="text-xs text-muted-foreground">
                📊 {stockData.dataSource.provider} · {stockData.dataSource.lastUpdated}
              </p>
              <p className="text-xs text-muted-foreground">
                ⚠️ {stockData.dataSource.note}
              </p>
              {stockData.dataSource.disclaimer && (
                <p className="text-xs text-muted-foreground">
                  💡 {stockData.dataSource.disclaimer}
                </p>
              )}
            </div>
          ) : null}
        </section>
      </main>
    </div>
  )
}
